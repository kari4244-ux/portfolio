﻿Console.WriteLine("Podaj a");
int a = int.Parse(Console.ReadLine());
int l = a;
Console.WriteLine("Podaj b");
int b = int.Parse(Console.ReadLine());
int m = b;
bool znalezione = false;
int r = 0;

if (a != b)
{
    while (!znalezione)
    {
        if (a > b)
        {
            r = a % b;
            if (r == 0)
            {
                Console.WriteLine("NWD liczb " + l + " i " + m + " wynosi " + b);
                znalezione = true;
            }
            else
            {
                a = b;
                b = r;
            }
        }
        else if (b > a)
        {
            r = b % a;
            if (r == 0)
            {
                Console.WriteLine("NWD liczb " + l + " i " + m + " wynosi " + a);
                znalezione = true;
            }
            else
            {
                b = a;
                a = r;
            }
        }
    }
}

