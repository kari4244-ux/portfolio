using System;
using System.Text;
using System.Windows.Forms;

namespace generator_hasel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label2.Text = trackBar1.Value.ToString();
        }
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label2.Text = trackBar1.Value.ToString();
        }
        private void ShowError(string message)
        {
            label4.Text = "B��d: " + message;
        }
        private void ShowInfo(string message)
        {
            label4.Text = message;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = "";

            int dlugosc = trackBar1.Value;
            StringBuilder znaki = new StringBuilder();
            if (checkedListBox1.CheckedItems.Contains("Cyfry"))
                znaki.Append("0123456789");
            if (checkedListBox1.CheckedItems.Contains("Du�e litery"))
                znaki.Append("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            if (checkedListBox1.CheckedItems.Contains("Ma�e litery"))
                znaki.Append("abcdefghijklmnopqrstuvwxyz");
            if (checkedListBox1.CheckedItems.Contains("Znaki specjalne"))
                znaki.Append("!@#$%^&*()_+[]{};:,.<>?/|\\-=~");

            if (znaki.Length == 0)
            {
                ShowError("Nale�y zaznaczy� przynajmniej jeden rodzaj znak�w.");
                return;
            }

            Random rnd = new Random();
            StringBuilder haslo = new StringBuilder();

            for (int i = 0; i < dlugosc; i++)
            {
                int index = rnd.Next(znaki.Length);
                haslo.Append(znaki[index]);
            }
            textBox1.Text = haslo.ToString();
            ShowInfo("Has�o wygenerowane.");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                Clipboard.SetText(textBox1.Text);
                ShowInfo("Skopiowano do schowka.");
            }
            else
            {
                ShowError("Brak has�a do skopiowania.");
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            ShowInfo("Wyczyszczono.");
        }
    }
}