﻿namespace generator_hasel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button1 = new Button();
            label3 = new Label();
            checkedListBox1 = new CheckedListBox();
            label2 = new Label();
            label1 = new Label();
            trackBar1 = new TrackBar();
            groupBox2 = new GroupBox();
            label4 = new Label();
            button3 = new Button();
            button2 = new Button();
            textBox1 = new TextBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(checkedListBox1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(trackBar1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(273, 214);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Generowanie hasła:";
            // 
            // button1
            // 
            button1.Location = new Point(66, 181);
            button1.Name = "button1";
            button1.Size = new Size(130, 23);
            button1.TabIndex = 5;
            button1.Text = "Wygeneruj hasło.";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 85);
            label3.Name = "label3";
            label3.Size = new Size(88, 15);
            label3.TabIndex = 4;
            label3.Text = "Wybór znaków:";
            // 
            // checkedListBox1
            // 
            checkedListBox1.BackColor = SystemColors.Menu;
            checkedListBox1.BorderStyle = BorderStyle.None;
            checkedListBox1.CheckOnClick = true;
            checkedListBox1.Cursor = Cursors.Hand;
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "Cyfry", "Duże litery", "Małe litery", "Znaki specjalne" });
            checkedListBox1.Location = new Point(6, 103);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(261, 72);
            checkedListBox1.Sorted = true;
            checkedListBox1.TabIndex = 3;
            checkedListBox1.ThreeDCheckBoxes = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(248, 37);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 2;
            label2.Text = "1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 19);
            label1.Name = "label1";
            label1.Size = new Size(173, 15);
            label1.TabIndex = 1;
            label1.Text = "Długość hasła (min. 1, max. 32):";
            // 
            // trackBar1
            // 
            trackBar1.Cursor = Cursors.Hand;
            trackBar1.Location = new Point(6, 37);
            trackBar1.Maximum = 32;
            trackBar1.Minimum = 1;
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(236, 45);
            trackBar1.TabIndex = 0;
            trackBar1.Value = 1;
            trackBar1.Scroll += trackBar1_Scroll;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(button3);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Location = new Point(291, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(273, 214);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Hasło:";
            // 
            // label4
            // 
            label4.Location = new Point(6, 85);
            label4.Name = "label4";
            label4.Size = new Size(261, 119);
            label4.TabIndex = 3;
            // 
            // button3
            // 
            button3.Location = new Point(139, 51);
            button3.Name = "button3";
            button3.Size = new Size(128, 23);
            button3.TabIndex = 2;
            button3.Text = "Wyczyść.";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(6, 51);
            button2.Name = "button2";
            button2.Size = new Size(128, 23);
            button2.TabIndex = 1;
            button2.Text = "Kopiuj do schowka.";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(6, 22);
            textBox1.MaxLength = 32;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Tutaj pojawi się wygenerowane hasło.";
            textBox1.Size = new Size(261, 23);
            textBox1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(577, 238);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Generator haseł - Karina Życzyńska 3TP";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private TrackBar trackBar1;
        private Label label1;
        private Label label2;
        private CheckedListBox checkedListBox1;
        private Label label3;
        private TextBox textBox1;
        private Button button1;
        private Button button3;
        private Button button2;
        private Label label4;
    }
}
