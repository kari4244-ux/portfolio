﻿using System;

namespace Program
{
    class FizzBuzz
    {
        private int liczba;

        public FizzBuzz(int liczba)
        {
            this.liczba = liczba;
        }

        public string Obliczanie()
        {
            if (liczba % 3 == 0 && liczba % 5 == 0)
            {
                return "FizzBuzz";
            }
            else if (liczba % 3 == 0)
            {
                return "Fizz";
            }
            else if (liczba % 5 == 0)
            {
                return "Buzz";
            }
            else
            {
                return liczba.ToString();
            }
        }

        static void Main(string[] args)
        {
            Console.Write("Podaj liczbę: ");
            int liczba = int.Parse(Console.ReadLine());

            FizzBuzz fizzBuzz = new FizzBuzz(liczba);
            Console.WriteLine(fizzBuzz.Obliczanie());
        }
    }
}
