﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace przeliczanie_systemów
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int liczba = int.Parse(dziesiatka.Text);
            bool naMinusie = false;
            string wynikL = "";
            if (liczba <0)
            {
                liczba = liczba*-1;
                naMinusie = true;
            }
            while (liczba > 0)
            {
                int nowaLiczba = liczba % 2;
                liczba = liczba / 2;
                wynikL = nowaLiczba + wynikL;
            }
            if (naMinusie == true)
            {
                wynik.Text = "-" + wynikL;
            }
            else
            {
                wynik.Text = wynikL;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int liczba = int.Parse(dziesiatka.Text);
            string wynikL = "";
            bool naMinusie = false;
            if (liczba < 0)
            {
                liczba = liczba * -1;
                naMinusie = true;
            }
            while (liczba > 0)
            {
                int nowaliczba = liczba % 8;
                liczba = liczba / 8;
                wynikL = nowaliczba + wynikL;
            }
            if (naMinusie == true)
            {
                wynik.Text = "-" + wynikL;
            }
            else
            {
                wynik.Text = wynikL;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int liczba = int.Parse(dziesiatka.Text);
            string wynikL = "";
            bool naMinusie = false;
            char[] szes = "0123456789ABCDEF".ToCharArray();
            if (liczba < 0)
            {
                liczba = liczba * -1;
                naMinusie = true;
            }
            while (liczba > 0)
            {
                int nowaliczba = liczba % 16;
                wynikL = szes[nowaliczba] + wynikL;
                liczba = liczba / 16;
            }
            if (naMinusie == true)
            {
                wynik.Text = "-" + wynikL;
            }
            else
            {
                wynik.Text = wynikL;
            }
        }
    }
}