﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kalkulator_polki
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            blad.Content = "";
            string dlugosc1 = dlugosc.Text;
            int dlugoscPolki = 0;
            if (dlugosc1 == "")
            {
                dlugosc1 = "1";
                blad.Content = "podaj poprawną długość";
            }
            else
            {
                dlugoscPolki = int.Parse(dlugosc1);
                if (dlugoscPolki < 20 || dlugoscPolki > 300)
                {
                    blad.Content = "Niepoprawna długość (20 - 300)";
                    dlugosc.Text = "";
                    glebokosc.Text = "";
                    ilosc.Text = "";
                    cenaM.Text = "";
                }
            }
            string glebokosc1 = glebokosc.Text;
            int glebokoscPolki = 0;
            if (glebokosc1 == "")
            {
                glebokosc1 = "1";
                blad.Content = "podaj poprawną głębokość";
            }
            else
            {
                glebokoscPolki = int.Parse (glebokosc1);
                if (glebokoscPolki < 10 || glebokoscPolki > 100)
                {
                    blad.Content = "Niepoprawna głębokość (10 - 100)";
                    dlugosc.Text = "";
                    glebokosc.Text = "";
                    ilosc.Text = "";
                    cenaM.Text = "";
                }
            }
            string ilosc1 = ilosc.Text;
            int iloscPolek = 0;
            if (ilosc1 == "")
            {
                ilosc1 = "1";
                blad.Content = "podaj poprawną liczbę półek";
            }
            else
            {
                iloscPolek |= int.Parse (ilosc1);
                if (iloscPolek < 1 || iloscPolek > 50)
                {
                    blad.Content = "Niepoprawna ilość półek (1 - 50)";
                    dlugosc.Text = "";
                    glebokosc.Text = "";
                    ilosc.Text = "";
                    cenaM.Text = "";
                }
            }
            string cena1 = cenaM.Text;
            int cenaZaMetr = 0;
            if ((cena1 == "")) {
                cena1 = "1";
                blad.Content = "Podaj poprawną cenę";
            }
            else {
                cenaZaMetr |= int.Parse (cena1);
                if (cenaZaMetr < 1 || cenaZaMetr > 1000)
                {
                    blad.Content = "Niepoprawna cena za metr (1 - 1000)";
                    dlugosc.Text = "";
                    glebokosc.Text = "";
                    ilosc.Text = "";
                    cenaM.Text = "";
                }
            }
                double powierzchniaDzialanie = (dlugoscPolki / 10) * (glebokoscPolki / 10) * iloscPolek;
                double powierzchnia = powierzchniaDzialanie / 100;


                if ((bool)zapas.IsChecked)
                {
                    double powierzchniaExtra = powierzchnia;
                    powierzchniaExtra = powierzchniaExtra * 1.10;
                    double doZaplaty = powierzchniaExtra * cenaZaMetr;
                    netto.Text = powierzchnia.ToString("F2") + "m2";
                    ostatecznaPowierzchnia.Text = powierzchniaExtra.ToString("F2") + "m2";
                    ostatecznaCena.Text = doZaplaty.ToString("F2") + " zł";
                }
                else
                {
                    double doZaplaty = powierzchnia * cenaZaMetr;
                    netto.Text = powierzchnia.ToString("F2") + "m2";
                    ostatecznaPowierzchnia.Text = powierzchnia.ToString("F2") + "m2";
                    ostatecznaCena.Text = doZaplaty.ToString("F2") + " zł";
            }


            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            dlugosc.Text = "";
            glebokosc.Text = "";
            ilosc.Text = "";
            cenaM.Text = "";
            netto.Text = "";
            ostatecznaPowierzchnia.Text = "";
            ostatecznaCena.Text = "";
            blad.Content = "";
        }
    }

}