﻿
bool podany = false;
int[] pesel = new int[11];
int s = 0;
int m = 0;
int r = 0;
string plec = "";


Console.WriteLine("podaj PESEL wpisując pojeduncze liczby + Enter");

for (int i = 0; i <= 10; i++)
{
    pesel[i] = int.Parse(Console.ReadLine());
}
if (pesel[9] % 2 == 0)
{
    plec = "K";
}
else
{
    plec = "M";
}

s = (pesel[0] * 1) + (pesel[1] * 3) + (pesel[2] * 7) + (pesel[3] * 9) + (pesel[4] * 1) + (pesel[5] * 3) + (pesel[6] * 7) + (pesel[7] * 9) + (pesel[8] * 1) + (pesel[9] * 3);
m = s % 10;
if (m == 0)
{
    r = 0;
}
else
{
    r = 10 - m;
}

if (pesel[10] == r)
{
    Console.WriteLine("Pesel jest poprawny. płeć " + plec);
}
else
{
    Console.WriteLine("pesel jest niepoprawny");
}
