﻿Console.WriteLine("podaj ciąg znaków do odwrócenia");
string ciag = Console.ReadLine();
string odwrocone = "";

foreach (char c in ciag)
{
    odwrocone = c + odwrocone;
}
Console.WriteLine(ciag + " odwrotnie to " + odwrocone);