﻿using System.Diagnostics.Eventing.Reader;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace rejesttracja_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string haslo = hasloT.Text;
            string powtorzenie = powtorzT.Text;
            bool poprawnyEmail = false;


            while (!poprawnyEmail)
            {
                string email = emailT.Text;
                foreach (char c in email)
                {
                    if (c == '@')
                    {
                        poprawnyEmail = true;
                        bool poprawneHaslo = false;
                        if (poprawnyEmail == true)
                        {
                            while (poprawneHaslo == false)
                            {
                                if (haslo == "")
                                {
                                    wynik.Content = "hasło nie może być puste";
                                    hasloT.Clear();
                                    powtorzT.Clear();
                                    haslo = " ";
                                    powtorzenie = " ";
                                    return;
                                }
                                if (haslo == powtorzenie)
                                {
                                    wynik.Content = "Witaj " + email;
                                    poprawneHaslo = true;
                                }
                                else if (haslo != powtorzenie)
                                {
                                    wynik.Content = "Hasła muszą być takie same";
                                    hasloT.Clear();
                                    powtorzT.Clear();
                                    haslo = " ";
                                    powtorzenie = " ";
                                    return;
                                }
                            }
                        }

                    }

                }
                if (!poprawnyEmail)
                {
                    wynik.Content = "Niepoprawny Email";
                    emailT.Clear();
                    email = "";
                    return;
                }

            }

        }
    }
}