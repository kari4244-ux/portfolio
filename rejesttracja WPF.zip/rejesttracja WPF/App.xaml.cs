﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace rejesttracja_WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
