﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace kalkulator_kosztów_kserowania
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
