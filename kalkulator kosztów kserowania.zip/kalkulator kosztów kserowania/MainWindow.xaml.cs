﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kalkulator_kosztów_kserowania
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (kopie.Text =="" || strony.Text=="")
            {
                koszt.Text = "błąd";
                return;
            }
            int kopie2 = int.Parse(kopie.Text);
            int strony2 = int.Parse(strony.Text);
            int liczbaStron = kopie2 * strony2;
            double cenaS;
            int liczbaArkuszy;
                if ((bool)kolorowa.IsChecked)
                {
                    cenaS = 0.60;
                }
                else
                {
                    cenaS = 0.15;
                }
                
                if ((bool)dwustronny.IsChecked)
                {
                    strony2 = strony2 / 2;
                    liczbaArkuszy = (kopie2 * strony2)/2;
                }
                else
                {
                    liczbaArkuszy = kopie2 * liczbaStron;
                }
            double kosztDruku = liczbaStron * cenaS;

            doKopii.Text = liczbaStron.ToString();
            arkusze.Text = liczbaArkuszy.ToString();
            kosztDruku = Math.Round(kosztDruku, 2);
            koszt.Text =kosztDruku.ToString() + "zł";
        }

        private void wyczysc_Click(object sender, RoutedEventArgs e)
        {
            kopie.Text = "";
            strony.Text = "";
            doKopii.Text = "";
            arkusze.Text = "";
            koszt.Text = "";
        }
    }
}