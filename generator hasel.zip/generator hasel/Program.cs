﻿Random ind = new Random();
int licznik = 0;
int[] kolejnosc = [1, 2, 3, 4, 5];
while (licznik <= 5)
{
            string haslo = "";
                for (int i = 0; i <= 2; i++)
                {
                    string znakiMale = "qwertyuiopasdfghjklzxcvbnm";
                    int x = ind.Next(26);

                    haslo = haslo + znakiMale[x];
                }
                for (int j = 0; j <= 2; j++)
                {
                    string znakiWielkie = "QWERTYUIOPASDFGHJKLZXCVBNM";
                    int y = ind.Next(26);

                    haslo = haslo + znakiWielkie[y];
                }
                for (int k = 0; k <= 2; k++)
                {
                    string znakiDiaktryczne = "ąęłńóśżźĄĘŁŃÓŚŻŹ";
                    int z = ind.Next(16);

                    haslo = haslo + znakiDiaktryczne[z];
                }
                for (int l = 0; l <= 1; l++)
                {
                    string liczby = "0123456789";
                    int a = ind.Next(10);

                    haslo = haslo + liczby[a];
                }
                for (int m = 0; m <= 1; m++)
                {
                    string znakiSpecjalne = "!@#$%^&*()_+";
                    int b = ind.Next(12);

                    haslo = haslo + znakiSpecjalne[b];
                }
            Console.WriteLine(haslo);
            licznik++;
        }
    


