package com.example.domekwgrach;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView polubienia;
    Button jeden, dwa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_main);
        polubienia = findViewById(R.id.polubienia);
        jeden = findViewById(R.id.jeden);
        dwa = findViewById(R.id.dwa);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    int iloscPolubien = 0;
    public void polub(View view) {
        iloscPolubien++;
        polubienia.setText("polubienia "+ iloscPolubien);
    }
    public void usun(View view) {
        if (iloscPolubien > 0) {
            iloscPolubien--;
            polubienia.setText("polubienia "+ iloscPolubien);
        }
    }
}