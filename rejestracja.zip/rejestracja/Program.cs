﻿using System.Globalization;

bool znaleziony = false; //ustawienie flagi emaila

while (znaleziony == false)
{
    Console.WriteLine("podaj email"); 
    string email = Console.ReadLine();  //pobranie emaila od użytkownika
    foreach (char c in email)   //sprawdzenie poprawności emaila
    {
        if (c == '@')
        {
            znaleziony = true;  //zamknięcie pętli pobrania emaila
            bool zhaslo = false;    //ustawienie flagi hasła
            while (zhaslo == false)
            {
                Console.WriteLine("podaj haslo");   //pobranie hasła od użytkownika
                string haslo = Console.ReadLine();
                if (haslo != "")    //sprawdzenie czy hasło nie jest puste 
                {
                    Console.WriteLine("powtórz hasło");
                    string powtorzenie = Console.ReadLine();
                    if (haslo == powtorzenie)   //sprawdzenie poprawności hasła
                    {
                        Console.WriteLine("witaj " + email);    //wyświetlenie komunikatu sukcesu
                        zhaslo = true;  //zakończenie programu poprzez zmianę flagi
                    }
                    else
                    {
                        Console.WriteLine("hasła muszą być takie same");    //wyświetlenie komunikatu o błędzie hasła
                    }
                }
                else
                {
                    Console.WriteLine("haslo nie moze być puste");  //zwrócenie błędu jeżeli hasło jest puste
                }
            }
        }
    }

    if (!znaleziony)
    {
        Console.WriteLine("email musi zawierać @"); //wyświetlenie komunikatu o błędzie emaila
    }

}