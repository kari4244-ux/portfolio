﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace działania
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (textbox1 != null && textbox2 != null)
            {
                float liczba1 = float.Parse(textbox1.Text);
                float liczba2 = float.Parse(textbox2.Text);
                string wynik = (liczba1 + liczba2).ToString();
                wyswietl.Text = wynik;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (textbox1 != null && textbox2 != null)
            {
                float liczba1 = float.Parse(textbox1.Text);
                float liczba2 = float.Parse(textbox2.Text);
                string wynik = (liczba1 - liczba2).ToString();
                wyswietl.Text = wynik;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (textbox1 != null && textbox2 != null)
            {
                float liczba1 = float.Parse(textbox1.Text);
                float liczba2 = float.Parse(textbox2.Text);
                string wynik = (liczba1 * liczba2).ToString();
                wyswietl.Text = wynik;
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (textbox1 != null && textbox2 != null)
            {
                float liczba1 = float.Parse(textbox1.Text);
                float liczba2 = float.Parse(textbox2.Text);
                if (liczba2 != 0)
                {
                    string wynik = (liczba1 / liczba2).ToString();
                    wyswietl.Text = wynik;
                }
                else
                {
                    wyswietl.Text = "nie można dzielić przez 0";
                }

            }
        }
    }
}