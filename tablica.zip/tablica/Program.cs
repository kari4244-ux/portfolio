﻿int[] tablica = new int[1000];
Random rand = new Random();
int suma = 0;
for (int i = 0; i <= 999; i++)
{
    tablica[i] = rand.Next(1000);
}
foreach (int i in tablica)
{
    Console.WriteLine(i);
}
Console.WriteLine("nieparzyste:");
foreach (int i in tablica)
{
    if (i % 2 != 0)
    {
        Console.WriteLine(i);
    }
}
for (int j = 0; j < tablica.Length; j++)
{
    suma += tablica[j];
}
int srednia = suma / tablica.Length;
Console.WriteLine("Srednia elementów wynosi " + srednia);
Console.WriteLine("podaj liczbę do wyszukania");
int szukana = int.Parse(Console.ReadLine());

foreach (int i in tablica)
{
    if (i == szukana)
    {
        Console.WriteLine(i +": " + tablica[i]);
    }
}