﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace kosci
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
