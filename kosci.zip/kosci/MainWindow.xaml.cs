﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kosci
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();  //definicja losowej liczby

            int one = rnd.Next(1, 7);   //generowanie pięciu losowych zmiennych odpowiadających kostkom
            int two = rnd.Next(1, 7);
            int three = rnd.Next(1, 7);
            int four = rnd.Next(1, 7);
            int five = rnd.Next(1, 7);


            diceOne.Text = one.ToString();  //wyświetlenie zmiennych w oknach tekstowych
            diceTwo.Text = two.ToString();
            diceThree.Text = three.ToString();
            diceFour.Text = four.ToString();
            diceFive.Text = five.ToString();

            int outcome = one + two + three + four + five;  //dodanie kostek
            Score.Text = outcome.ToString();    //wypisanie wyniku w oknie
        }
    }
}