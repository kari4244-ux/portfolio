﻿using System;

class program
{

    static void Main()
    {
        Console.WriteLine("podaj ciąg znaków");
        string ciag = Console.ReadLine();

        char[] tablica = ciag.ToCharArray();

        Array.Reverse(tablica);
        string ostatecznatablica = new string(tablica);

        Console.WriteLine(ciag + " odwrotnie to " + ostatecznatablica);
    }
}