﻿bool powtorz = false;
int min = 1;
int max = 6;
int punty = 0;
int calkowitywynik = 0;
bool gry = false;
bool odpowiedz = false;

while (!powtorz)
{
    while (!gry)
    {
        odpowiedz = false;
        Console.WriteLine("Podaj ilość rzutów od 3 do 10");
        int ilosc = int.Parse(Console.ReadLine());
        if (ilosc <= 10 && ilosc >= 3)
        {
            int[] rzuty = new int[ilosc];
            powtorz = true;
            Random rand = new Random();
            for (int i = 0; i < rzuty.Length; i++)
            {
                rzuty[i] = rand.Next(min, max);
                int numer = i + 1;
                Console.WriteLine("rzut numer " + numer + ": " + rzuty[i]);
            }
            for (int r = 0; r < rzuty.Length; r++)
            {
                punty = punty + rzuty[r];
                
            }
            calkowitywynik = calkowitywynik + punty;

            Console.WriteLine("zdobyłeś " + punty + " punktów.Powtórzyć? Y/N"); 
            while (!odpowiedz) { 
                string potwierdzenie = Console.ReadLine();
                if (potwierdzenie.ToLower() == "n")
                {
                    gry = true;
                    Console.WriteLine("całkowity wynik wynosi: " + calkowitywynik);
                    odpowiedz = true;
                }
                else if (potwierdzenie.ToLower() != "y")
                {
                    Console.WriteLine("podaj poprawną odpowiedź");
                }
                else
                {
                    odpowiedz = true;
                }
            }
         }
    }
}

