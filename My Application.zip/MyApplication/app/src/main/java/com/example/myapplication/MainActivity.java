package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText email, haslo, powtorzenie;
    Button wyslij;
    TextView monit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_main);

        email = findViewById(R.id.email);
        haslo = findViewById(R.id.haslo);
        powtorzenie = findViewById(R.id.powtorzenie);
        wyslij = findViewById(R.id.wyslij);
        monit = findViewById(R.id.monit);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void onClick(View view) {
        var wprowadzonyEmail = email.getText().toString();
        var wprowadzoneHaslo = haslo.getText().toString();
        var wprowadzonePowtorzenie = powtorzenie.getText().toString();

        if (wprowadzoneHaslo.isEmpty() || wprowadzoneHaslo.trim().isEmpty()) {
            monit.setTextColor(Color.parseColor("#F54927"));
            monit.setText("hasło nie może być puste");
        }
        else if (wprowadzoneHaslo.length() < 8) {
            monit.setTextColor(Color.parseColor("#F54927"));
            monit.setText("hasło musi zawierać co najmniej 8 znaków");
        }
        else {

            boolean malpa = wprowadzonyEmail.contains("@");
            boolean hasla = wprowadzoneHaslo.equals(wprowadzonePowtorzenie);



            if (!malpa) {
                monit.setTextColor(Color.parseColor("#F54927"));
                monit.setText("Błędny email");
            }
            else if (!hasla) {
                monit.setTextColor(Color.parseColor("#F54927"));
                monit.setText("Hasła nie są takie same");
            }
            else {
                monit.setTextColor(Color.parseColor("#808080"));
                monit.setText("Witaj " + wprowadzonyEmail);
            }

        }
    }
}