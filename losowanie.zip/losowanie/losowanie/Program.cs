﻿Console.WriteLine("Ile wygenerować losowań?");
int ilosc = int.Parse(Console.ReadLine());
int los = 0;

for (int i = 0; i< ilosc; i++)
{
    los++;
    int[] losowanie = new int[6];
    int powtorz = 0;
    while (powtorz <= 5)
    {
        Random rand = new Random();
        int ind = rand.Next(1, 50);
        losowanie[powtorz] = ind;
        powtorz++;

        bool rozne = false;
        while (!rozne)
        {
            for (int j = 0; j < losowanie.Length; j++)
            {
                for (int k = j + 1; k < losowanie.Length; k++)
                {
                    if (losowanie[j] == losowanie[k])
                    {
                        losowanie[j] = rand.Next(1, 50);
                    }
                }
            }
            rozne = true;
        }
    }
    Console.WriteLine("losowanie " + los + " ");
    foreach (int l in losowanie)
    {
        Console.Write(l.ToString() + " ");
    }
    Console.WriteLine(); 
}
