﻿Random rand = new Random();
int liczba = rand.Next(1, 101);
int proby = 0;
bool trafione = false;

while (!trafione)
{
    proby++;
    Console.WriteLine("zgadnij liczbęod 1 do 100");
    int odpowiedz = int.Parse(Console.ReadLine());
    if (odpowiedz < liczba)
    {
        Console.WriteLine("za mało");
    }
    else if (odpowiedz > liczba)
    {
        Console.WriteLine("za dużo");
    }
    else if (odpowiedz == liczba)
    {
        Console.WriteLine("Gratulację! Liczba to " + liczba + ". Odgadłeś ją w " + proby + " prób.");
        trafione = true;
    }
}

