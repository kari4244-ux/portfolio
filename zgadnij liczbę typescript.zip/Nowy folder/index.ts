import * as readlineSync from 'readline-sync';  //import biblioteki readline

var losowa = Math.floor(Math.random()*100+1);   //losowanie liczby od 1 do 100
console.log("odgadnij liczbę od 1 do 100");
var podejscia = 0;  //deklarowanie zmiennej zliczającej ilość podejść
var odgadnieta = false; //deklarowanie flagi kontunuującej grę

while (!odgadnieta) {
    var podanaLiczba = readlineSync.questionFloat('podaj liczbe '); //pobranie liczby od użytkownika
    if (podanaLiczba > losowa) {
        console.log("za dużo.");
        podejscia++;
    }   //pętla zwracająca informację jeżeli liczba jest za mała
    else if (podanaLiczba < losowa) {
        console.log("za mało");
        podejscia++
    }   //pętla zwracająca informację jeżeli liczba jest za duża
    else if (podanaLiczba == losowa) {
        podejscia++;
        console.log("Gratulacje! liczba to " + losowa + ". odgadłeś ją w " + podejscia + " podejść.");
        odgadnieta = true;
    }   //zakończenie gry i podanie liczby podejść
}
