﻿//program sprawdza czy podany wyraz jest palindromem, czyli taki sam napisany od tyłu.

Console.WriteLine("podaj wyraz do sprawdzenia");
string wyraz = Console.ReadLine();
string zaryw = "";

foreach (char c in wyraz)
{
    zaryw = c + zaryw;
}

if (wyraz.ToLower() == zaryw.ToLower()) {
    Console.WriteLine("wyraz " + wyraz + " jest palindromem.");
}
else
{
    Console.WriteLine("wyraz " + wyraz + " nie jest palindromem. Od tyłu brzmi on " + zaryw);
}
