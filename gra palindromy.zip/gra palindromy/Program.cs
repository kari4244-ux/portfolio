﻿Console.WriteLine("Celem gry jest podanie jak największej ilości wyrazów, które są palindromami, czyli tak samo pisane od tyłu.");
Console.WriteLine("podaj pierwszy wyraz aby zacząć. wpisz 'koniec', aby zakończyć grę");
int podejscia = 0;
int trafienia = 0;
bool koniec = false;

while (!koniec)
{
    string wyraz = Console.ReadLine();
    string zaryw = "";
    foreach (char c in wyraz)
    {
        zaryw = c + zaryw;
    }
    if (wyraz.ToLower() == "koniec")
    {
        koniec = true;
        Console.WriteLine("twój wynik to " + podejscia + " podejsc, z czego " + trafienia + " z nich to trafienia");
    }
    else
    {
        if (zaryw.ToLower() == wyraz.ToLower())
        {
            Console.WriteLine("prawidłowo");
            podejscia++;
            trafienia++;
        }
        else
        {
            Console.WriteLine("błąd. spróbuj jeszcze raz");
            podejscia++;
        }
    }
}
