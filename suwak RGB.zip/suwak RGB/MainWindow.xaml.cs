﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace suwak_RGB
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            sliderRed.Value = 255;
            sliderGreen.Value = 255;
            sliderBlue.Value = 255;
        }
        int r = 0;
        int g = 0;
        int b = 0;

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            /**********************************************
             * nazwa funkcji: zmiana suwaka
             * opis funcji:   funkcja reaguje na zmianę wartości suwaka. zostaje ona pobrana i przypisana do zmiennej,
             * a potem użyta do zmiany koloru tła prostokątu na ekranie.
             * parametry:   r - liczba całkowita przechowująca wartość suwaka
             *              valueR - etykieta, która wyświetla wartość suwaka
             * zwracany typ i opis: r - wartość koloru czerwonego w wyniku
             * autor:   00000000000
             **********************************************/
            r = (int)sliderRed.Value;
            valueR.Content = r;

            view.Fill = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
        }

        private void Slider_ValueChanged_1(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            g = (int)sliderGreen.Value;
            valueG.Content = g;

            view.Fill = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
        }

        private void sliderBlue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            b = (int)sliderBlue.Value;
            valueB.Content = b;

            view.Fill = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
        }

        private void submit_Click(object sender, RoutedEventArgs e)
        {
            score.Content = r + ", " + g + ", " + b;
            score.Background = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
        }
    }
}