﻿Console.WriteLine("Podaj a");
int a = int.Parse(Console.ReadLine());
Console.WriteLine("Podaj b");
int b = int.Parse(Console.ReadLine());

while (a != b)
{
    if (a > b)
    {
        a = a - b;
    }
    else if (b > a)
    {
        b = b - a;
    }
}
Console.WriteLine("NWD z liczb wynosi " + a);
